import json

def generateweather():
    pass 

if __name__ == "__main__":
    generateweather()
